package com.capgemini.dao;

public interface QueryMapper {

	//public static final String RETRIVE_ALL_QUERY="SELECT donor_name,address,phone_number,donor_date,donor_amount FROM donor_details";
	//public static final String VIEW_DONAR_DETAILS_QUERY="SELECT donor_name,address,phone_number,donor_date,donor_amount FROM donor_details WHERE  donor_id=?";
	public static final String INSERT_QUERY="INSERT INTO Patient VALUES(Patient_Id_Seq.NEXTVAL,?,?,?,?, (select SYSDATE from DUAL))";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT Patient_Id_Seq.CURRVAL FROM DUAL";
	public static final String VIEW_PATIENT_DETAILS_QUERY = "SELECT name,age,phone_number,description FROM Patient_details WHERE  patient_id=?";;
	
	
}